class PrivelegedAccount {
    constructor (id, title, f_name, l_name, username, access_level, access_flags){
        this.id = id;
        this.title = title;
        this.f_name = f_name;
        this.l_name = l_name;
        this.username = username;
        this.access_level = access_level;
        this.access_flags = access_flags;
    }

    get access_flags() {
        return this.access_flags;
    }
    
    set access_flags(flags){
        this.access_flags = flags;
        // Database update here.. (userService)
        return true
    }
}