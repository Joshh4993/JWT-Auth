require("dotenv").config()
const fs = require("fs")
const express = require("express")
const http = require("http")
const { Server } = require("socket.io")
const { PrivelegedAccount }= require("./models/PrivilegedAccount")

const app = express()
const server = http.createServer(app)
const io = new Server(server)

const accessUser = new PrivelegedAccount(1, "Title", "FNAME", "LNAME", "USERNAME", 190, [])

app.get('/', (req, res) => {
    res.send('<h1>hello</h1>')
})

console.log(accessUser)

io.on('connection', (socket) => {
    console.log('user connected')
})

server.listen(process.env.SERVER_SOCKET_PORT, () => {
    console.log(`Server listening on *:${process.env.SERVER_SOCKET_PORT}`)
})